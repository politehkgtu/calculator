import static java.lang.StrictMath.sqrt;

public class Model {
    private Viewer viewer;
    private String temp;
    private String leftValue;
    private String rightValue;
    private String action;

    //public String temp;
    public Model(Viewer viewer) {
        this.viewer = viewer;
        temp = "";
        leftValue = "";
        rightValue = "";
        action = "";
    }

    public void doAction(String command) {
        if (command.equals("Memory_Clear")) {
            System.out.println("Clear");
        } else if (command.equals("Memory_Read")) {
            System.out.println("Read");
        } else if (command.equals("One")) {
            temp = temp + "1";
        } else if (command.equals("Two")) {
            temp = temp + "2";
        } else if (command.equals("Three")) {
            temp = temp + "3";
        } else if (command.equals("Four")) {
            temp = temp + "4";
        } else if (command.equals("Five")) {
            temp = temp + "5";
        } else if (command.equals("Six")) {
            temp = temp + "6";
        } else if (command.equals("Seven")) {
            temp = temp + "7";
        } else if (command.equals("Eight")) {
            temp = temp + "8";
        } else if (command.equals("Nine")) {
            temp = temp + "9";
        } else if (command.equals("Zero")) {
            temp = temp + "0";
        }else if (command.equals("Comma")) {
            temp = temp + ".";
        } else if (command.equals("Plus")) {
            leftValue = temp;
            temp = "";
            action = "+";
            return;
        } else if (command.equals("Minus")) {
            leftValue = temp;
            temp = "";
            action = "-";
            return;
        } else if (command.equals("Multiple")) {
            leftValue = temp;
            temp = "";
            action = "*";
            return;
        } else if (command.equals("Divide")) {
            leftValue = temp;
            temp = "";
            action = "/";
            return;
        } else if (command.equals("Clear")) {
            temp = "";
            leftValue = temp;
            rightValue = temp;
            action = "";
            //return;
        } else if (command.equals("Backspace")) {
            String line = "";
            for (int i = 0; i < temp.length() - 1; i++) {
                char symbol = temp.charAt(i);
                line = line + symbol;
            }
            temp = line;
        } else if (command.equals("Plusminus")) {
            leftValue = temp;
            //temp =  "";
            action = "+-";
            return;
        } else if (command.equals("Root")) {
            leftValue = temp;
            //temp =  "";
            action = "Root";
            return;
        } else if (command.equals("Percent")) {
            leftValue = temp;
            temp =  "";
            action = "Percent";
            return;
        }else if (command.equals("Onetox")) {
            leftValue = temp;
            //temp =  "";
            action = "Onetox";
            return;
        } else if (command.equals("Equal")) {
            rightValue = temp;
            double leftNumber = Double.parseDouble(leftValue);
            double rightNumber = Double.parseDouble(rightValue);
            double answer = 0.0;

            switch (action) {
                case "+":
                    answer = rightNumber + leftNumber;
                    break;

                case "-":
                    answer = leftNumber - rightNumber;
                    break;

                case "*":
                    answer = leftNumber * rightNumber;
                    break;

                case "/":
                    answer = leftNumber / rightNumber;
                    break;

                case "+-":
                    answer = leftNumber * (-1);
                    break;
                case "Root":
                    answer = sqrt(leftNumber);
                    break;
                case "Onetox":
                    answer = 1/leftNumber;
                    break;
                /*case "Percent":
                    answer = (leftNumber * (rightNumber)/100);
                    break;*/

            }
            //если натуральное цисло то убирает последную 0 и точку
            temp = String.valueOf(answer);
            char point = temp.charAt(temp.length() - 2);
            char zero = temp.charAt(temp.length() - 1);
            //System.out.println("point = " + point);
            //System.out.println("zero = " + zero);

            if (point == '.' && zero == '0') {
                String line = "";
                for (int i = 0; i < temp.length() - 2; i++) {
                    char symbol = temp.charAt(i);
                    line = line + symbol;
                }
                temp = line;

            }
        }

        viewer.update(temp);
        //System.out.println(command);
    }

}
