import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
//import java.

public class Viewer {
    private JTextField textField;
    public Viewer(){
        Controller controller = new Controller(this);

        //Font font = new Font

        textField = new JTextField();             //take out right side
        textField.setBounds(50,50,380,50);
        textField.setHorizontalAlignment(JTextField.RIGHT);

        JButton buttonMC = new JButton("MC");
        buttonMC.setBounds(50,110,60,60);
        buttonMC.addActionListener(controller);
        buttonMC.setActionCommand("Memory_Clear");

        JButton buttonMR = new JButton("MR");
        buttonMR.setBounds(130,110,60,60);
        buttonMR.addActionListener(controller);
        buttonMR.setActionCommand("Memory_Read");

        JButton buttonMS = new JButton("MS");
        buttonMS.setBounds(210,110,60,60);

        JButton buttonMPlus = new JButton("M+");
        buttonMPlus.setBounds(290,110,60,60);

        JButton buttonMMinus = new JButton("M-");
        buttonMMinus.setBounds(370,110,60,60);

        JButton buttonBackspace = new JButton("<-");
        buttonBackspace.setBounds(50,190,60,60);
        buttonBackspace.addActionListener(controller);
        buttonBackspace.setActionCommand("Backspace");

        JButton buttonCE = new JButton("CE");
        buttonCE.setBounds(130,190,60,60);

        JButton buttonC = new JButton("C");
        buttonC.setBounds(210,190,60,60);
        buttonC.addActionListener(controller);
        buttonC.setActionCommand("Clear");

        JButton buttonPlusminus = new JButton("±");
        buttonPlusminus.setBounds(290,190,60,60);
        buttonPlusminus.addActionListener(controller);
        buttonPlusminus.setActionCommand("Plusminus");

        JButton buttonRoot = new JButton("√");
        buttonRoot.setBounds(370,190,60,60);
        buttonRoot.addActionListener(controller);
        buttonRoot.setActionCommand("Root");

        JButton buttonSeven = new JButton("7");
        buttonSeven.setBounds(50,270,60,60);
        buttonSeven.addActionListener(controller);
        buttonSeven.setActionCommand("Seven");

        JButton buttonEight = new JButton("8");
        buttonEight.setBounds(130,270,60,60);
        buttonEight.addActionListener(controller);
        buttonEight.setActionCommand("Eight");

        JButton buttonNine = new JButton("9");
        buttonNine.setBounds(210,270,60,60);
        buttonNine.addActionListener(controller);
        buttonNine.setActionCommand("Nine");

        JButton buttonDivision = new JButton("/");
        buttonDivision.setBounds(290,270,60,60);
        buttonDivision.addActionListener(controller);
        buttonDivision.setActionCommand("Divide");

        JButton buttonPercent = new JButton("%");
        buttonPercent.setBounds(370,270,60,60);
        buttonPercent.addActionListener(controller);
        buttonPercent.setActionCommand("Percent");

        JButton buttonFour = new JButton("4");
        buttonFour.setBounds(50,350,60,60);
        buttonFour.addActionListener(controller);
        buttonFour.setActionCommand("Four");

        JButton buttonFive = new JButton("5");
        buttonFive.setBounds(130,350,60,60);
        buttonFive.addActionListener(controller);
        buttonFive.setActionCommand("Five");

        JButton buttonSix = new JButton("6");
        buttonSix.setBounds(210,350,60,60);
        buttonSix.addActionListener(controller);
        buttonSix.setActionCommand("Six");

        JButton buttonMultiple = new JButton("*");
        buttonMultiple.setBounds(290,350,60,60);
        buttonMultiple.addActionListener(controller);
        buttonMultiple.setActionCommand("Multiple");

        JButton buttonOnetox = new JButton("1/x");
        buttonOnetox.setBounds(370,350,60,60);
        buttonOnetox.addActionListener(controller);
        buttonOnetox.setActionCommand("Onetox");

        JButton buttonOne = new JButton("1");
        buttonOne.setBounds(50,430,60,60);
        buttonOne.addActionListener(controller);
        buttonOne.setActionCommand("One");

        JButton buttonTwo = new JButton("2");
        buttonTwo.setBounds(130,430,60,60);
        buttonTwo.addActionListener(controller);
        buttonTwo.setActionCommand("Two");

        JButton buttonThree = new JButton("3");
        buttonThree.setBounds(210,430,60,60);
        buttonThree.addActionListener(controller);
        buttonThree.setActionCommand("Three");

        JButton buttonMinus = new JButton("-");
        buttonMinus.setBounds(290,430,60,60);
        buttonMinus.addActionListener(controller);
        buttonMinus.setActionCommand("Minus");

        JButton buttonEqual = new JButton("=");
        buttonEqual.setBounds(370,430,60,140);
        buttonEqual.addActionListener(controller);
        buttonEqual.setActionCommand("Equal");

        JButton buttonZero = new JButton("0");
        buttonZero.setBounds(50,510,140,60);
        buttonZero.addActionListener(controller);
        buttonZero.setActionCommand("Zero");

        JButton buttonComma = new JButton(",");
        buttonComma.setBounds(210,510,60,60);
        buttonComma.addActionListener(controller);
        buttonComma.setActionCommand("Comma");

        JButton buttonPlus = new JButton("+");
        buttonPlus.setBounds(290,510,60,60);
        buttonPlus.addActionListener(controller);
        buttonPlus.setActionCommand("Plus");







        JFrame frame = new JFrame("Calculator MVC");
        frame.setSize(500,700);
        frame.setLocation(200,50);
        frame.setLayout(null);
        frame.add(textField);
        frame.add(buttonMC);
        frame.add(buttonMR);
        frame.add(buttonMS);
        frame.add(buttonMPlus);
        frame.add(buttonMMinus);
        frame.add(buttonBackspace);
        frame.add(buttonCE);
        frame.add(buttonC);
        frame.add(buttonPlusminus);
        frame.add(buttonRoot);
        frame.add(buttonSeven);
        frame.add(buttonEight);
        frame.add(buttonNine);
        frame.add(buttonDivision);
        frame.add(buttonPercent);
        frame.add(buttonFour);
        frame.add(buttonFive);
        frame.add(buttonSix);
        frame.add(buttonMultiple);
        frame.add(buttonOnetox);
        frame.add(buttonOne);
        frame.add(buttonTwo);
        frame.add(buttonThree);
        frame.add(buttonMinus);
        frame.add(buttonEqual);
        frame.add(buttonZero);
        frame.add(buttonComma);
        frame.add(buttonPlus);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    public void update(String text){
        textField.setText(text);
    }

}
